class CategoryModel {
  String image;
  String name;
  String subtitle;

  CategoryModel({
    required this.image,
    required this.name,
    required this.subtitle,
  });
}

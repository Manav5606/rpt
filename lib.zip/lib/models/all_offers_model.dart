class AllOffersModel {
  String name;
  String image;
  double distance;

  AllOffersModel({
    required this.distance,
    required this.name,
    required this.image,
  });
}

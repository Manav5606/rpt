import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xffDD2863);
const kSecondaryColor = Color(0xff0A7986);
const kGreyColor = Color(0xffF6F7FA);
const kIconColor = Color(0xff616161);

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_svg/svg.dart';
import 'package:food_delivery/constants/colors.dart';
import 'package:badges/badges.dart';
import 'package:food_delivery/data/category_data.dart';
import 'package:food_delivery/widgets/all_offers.dart';
import 'package:food_delivery/widgets/all_offers_listview.dart';
import 'package:food_delivery/widgets/category_card.dart';
import 'package:food_delivery/widgets/search_field.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late ScrollController _scrollController;
  late ScrollController _categoryController;

  late AnimationController _hideFabAnimController;

  late double percent;
  int currentItems = 4;
  bool last = false;
  Color one = kPrimaryColor;
  Color? two = Colors.pink[100];

  @override
  void initState() {
    super.initState();
    percent = .50;
    _scrollController = ScrollController();
    _categoryController = ScrollController();
    _hideFabAnimController = AnimationController(
      vsync: this,
      duration: kThemeAnimationDuration,
      value: 1,
    );

    _scrollController.addListener(() {
      switch (_scrollController.position.userScrollDirection) {
        case ScrollDirection.forward:
          _hideFabAnimController.forward();
          break;
        case ScrollDirection.reverse:
          _hideFabAnimController.reverse();
          break;
        case ScrollDirection.idle:
          break;
      }
    });

    _categoryController.addListener(_scrollListener);
  }

  _scrollListener() {
    setState(() {
      if (_categoryController.position.pixels > 200) {
        setState(() {
          last = true;
        });
      } else {
        setState(() {
          last = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _hideFabAnimController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.only(top: 15, left: 10, right: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.location_on_rounded,
                      color: kPrimaryColor,
                      size: 22,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      "Home - Pernamitta, Ongole",
                      style: TextStyle(
                        fontFamily: 'MuseoSans',
                        fontWeight: FontWeight.w700,
                        fontSize: 18,
                      ),
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: Badge(
                    badgeColor: kPrimaryColor,
                    badgeContent: Text(
                      '1',
                      style: TextStyle(color: Colors.white),
                    ),
                    child: Icon(CupertinoIcons.chat_bubble),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 15,
            ),
            SearchField(),
            SizedBox(
              height: 15,
            ),
            Expanded(
              child: ListView(
                children: [
                  Container(
                    height: 153,
                    width: double.infinity,
                    child: ListView.separated(
                      controller: _categoryController,
                      itemCount: categories.length,
                      physics: PageScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      separatorBuilder: (context, index) {
                        return SizedBox(
                          width: 2,
                        );
                      },
                      itemBuilder: (context, index) {
                        currentItems = index;
                        return CategoryCard(category: categories[index]);
                      },
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Center(
                    child: SizedBox(
                      width: 50,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(2),
                        child: LinearProgressIndicator(
                          backgroundColor: last ? kSecondaryColor : kGreyColor,
                          color: last ? kGreyColor : kSecondaryColor,
                          value: percent,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  AllOffers(),
                  SizedBox(
                    height: 15,
                  ),
                  AllOffersListView(
                    controller: _scrollController,
                  ),
                  Container(
                    height: 150,
                    width: double.infinity,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Recipto",
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontFamily: 'MuseoSans',
                          fontSize: 30,
                          letterSpacing: 1,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      )),
      floatingActionButton: FadeTransition(
        opacity: _hideFabAnimController,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            SizedBox(
              height: 50,
              width: 50,
              child: FloatingActionButton(
                elevation: 1,
                onPressed: () {},
                backgroundColor: kSecondaryColor,
                child: SvgPicture.asset('assets/icons/cart.svg',
                    color: Colors.white, semanticsLabel: 'Acme Logo'),
              ),
            ),
            SizedBox(width: 15),
            FloatingActionButton(
              elevation: 1,
              backgroundColor: kPrimaryColor,
              onPressed: () {},
              child: Icon(Icons.camera_alt_outlined),
            ),
            SizedBox(width: 36),
          ],
        ),
      ),
    );
  }
}

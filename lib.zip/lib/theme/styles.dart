import 'package:flutter/material.dart';

class AppStyles {
  static const BODY_PADDING = EdgeInsets.symmetric(horizontal: 10);
}

import 'package:flutter/material.dart';
import 'package:food_delivery/data/all_offers_data.dart';
import 'package:food_delivery/models/all_offers_model.dart';

class AllOffersListView extends StatelessWidget {
  final ScrollController controller;
  const AllOffersListView({Key? key, required this.controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      controller: this.controller,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: data.length,
      itemBuilder: (context, index) {
        return ListViewChild(
          offer: data[index],
        );
      },
      separatorBuilder: (context, index) {
        return SizedBox(
          height: 10,
        );
      },
    );
  }
}

class ListViewChild extends StatelessWidget {
  final AllOffersModel offer;
  const ListViewChild({Key? key, required this.offer}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(
          backgroundImage: AssetImage(offer.image),
          backgroundColor: Colors.white,
          radius: 30,
        ),
        SizedBox(
          width: 10,
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                offer.name,
                style: TextStyle(
                  fontFamily: "MuseoSans",
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                "Delivery · Pickup ${offer.distance} mi",
                style: TextStyle(
                  fontFamily: "MuseoSans",
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
        Icon(
          Icons.arrow_forward_ios_rounded,
          color: Colors.grey,
        )
      ],
    );
  }
}

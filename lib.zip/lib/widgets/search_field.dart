import 'package:flutter/material.dart';
import 'package:food_delivery/constants/colors.dart';

class SearchField extends StatelessWidget {
  const SearchField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(10),
      elevation: 2,
      child: SizedBox(
        height: 42,
        child: TextFormField(
          decoration: InputDecoration(
            contentPadding: EdgeInsets.all(0),
            labelText: "Restaurent names, cuisine or dish ...",
            labelStyle: TextStyle(
              fontFamily: 'MuseoSans',
              fontSize: 20,
              color: Colors.grey[400],
            ),
            prefixIcon: Icon(
              Icons.search,
              color: kPrimaryColor,
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: BorderSide(
                color: kPrimaryColor,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: BorderSide(
                color: kPrimaryColor,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: BorderSide(
                color: Color(0xffE7EFF4),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

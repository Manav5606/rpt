import 'package:flutter/material.dart';
import 'package:food_delivery/constants/colors.dart';

class AllOffers extends StatelessWidget {
  const AllOffers({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(
              Icons.favorite,
              color: kPrimaryColor,
              size: 20,
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              "All Offers (90)",
              style: TextStyle(
                fontFamily: "MuseoSans",
                fontSize: 20,
                fontWeight: FontWeight.w700,
              ),
            )
          ],
        ),
        Row(
          children: [
            Text(
              "Sort by",
              style: TextStyle(
                fontFamily: "MuseoSans",
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
            Icon(Icons.keyboard_arrow_down_outlined)
          ],
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:food_delivery/models/category_model.dart';

class CategoryCard extends StatelessWidget {
  final CategoryModel category;
  const CategoryCard({
    Key? key,
    required this.category,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Container(
          height: 106,
          padding: EdgeInsets.all(7),
          margin: EdgeInsets.all(3),
          width: width * .295,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                blurRadius: 5,
                offset: Offset(2, 1),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                category.name,
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontFamily: 'MuseoSans',
                  fontSize: 16,
                ),
              ),
              Image.asset(
                'assets/images/test.png',
                height: 65,
              )
            ],
          ),
        ),
        SizedBox(
          height: 3,
        ),
        Container(
          width: 110,
          child: Center(
            child: Text(
              category.subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontFamily: 'MuseoSans',
                fontSize: 14,
                color: Colors.black54,
              ),
            ),
          ),
        )
      ],
    );
  }
}

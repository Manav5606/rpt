import 'package:food_delivery/models/all_offers_model.dart';

List<AllOffersModel> data = [
  AllOffersModel(
    distance: 0.9,
    name: "Publix",
    image: "assets/images/image4.png",
  ),
  AllOffersModel(
    distance: 18.0,
    name: "Sprout Farmer Market",
    image: "assets/images/image2.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Costco",
    image: "assets/images/image1.png",
  ),
  AllOffersModel(
    distance: 10.5,
    name: "Publix",
    image: "assets/images/image4.png",
  ),
  AllOffersModel(
    distance: 18.0,
    name: "Sprout Farmer Market",
    image: "assets/images/image2.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Costco",
    image: "assets/images/image1.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Publix",
    image: "assets/images/image4.png",
  ),
  AllOffersModel(
    distance: 18.0,
    name: "Sprout Farmer Market",
    image: "assets/images/image2.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Costco",
    image: "assets/images/image1.png",
  ),
  AllOffersModel(
    distance: 10.5,
    name: "Publix",
    image: "assets/images/image4.png",
  ),
  AllOffersModel(
    distance: 18.0,
    name: "Sprout Farmer Market",
    image: "assets/images/image2.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Costco",
    image: "assets/images/image1.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Publix",
    image: "assets/images/image4.png",
  ),
  AllOffersModel(
    distance: 18.0,
    name: "Sprout Farmer Market",
    image: "assets/images/image2.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Costco",
    image: "assets/images/image1.png",
  ),
  AllOffersModel(
    distance: 10.5,
    name: "Publix",
    image: "assets/images/image4.png",
  ),
  AllOffersModel(
    distance: 18.0,
    name: "Sprout Farmer Market",
    image: "assets/images/image2.png",
  ),
  AllOffersModel(
    distance: 0.9,
    name: "Costco",
    image: "assets/images/image1.png",
  ),
];

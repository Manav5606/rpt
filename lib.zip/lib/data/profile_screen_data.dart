import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery/constants/colors.dart';

class ProfileScreen {
  String name;
  Icon icon;

  ProfileScreen({
    required this.icon,
    required this.name,
  });
}

List<ProfileScreen> profileScreenData = [
  ProfileScreen(
      icon: Icon(
        Icons.shopping_cart_outlined,
        color: kIconColor,
      ),
      name: "Your Orders"),
  ProfileScreen(
      icon: Icon(
        Icons.settings_outlined,
        color: kIconColor,
      ),
      name: "Your account settings"),
  ProfileScreen(
      icon: Icon(
        Icons.star_outline,
        color: kIconColor,
      ),
      name: "Recipto Express"),
  ProfileScreen(
      icon: Icon(
        Icons.light_mode_outlined,
        color: kIconColor,
      ),
      name: "How Recipto works"),
  ProfileScreen(
      icon: Icon(
        CupertinoIcons.share,
        color: kIconColor,
      ),
      name: "Invite Friends"),
  ProfileScreen(
      icon: Icon(
        Icons.receipt_outlined,
        color: kIconColor,
      ),
      name: "Credit & coupon codes"),
  ProfileScreen(
      icon: Icon(
        Icons.help_outline,
        color: kIconColor,
      ),
      name: "Help"),
  ProfileScreen(
      icon: Icon(
        Icons.info_outline,
        color: kIconColor,
      ),
      name: "About this app"),
  ProfileScreen(
      icon: Icon(
        Icons.shopping_bag_outlined,
        color: kIconColor,
      ),
      name: "Become a Shopper"),
];

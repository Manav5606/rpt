import 'package:food_delivery/models/category_model.dart';

List<CategoryModel> categories = [
  CategoryModel(
      image: "https://placeimg.com/640/480/arch",
      name: "Grocery",
      subtitle: "Enjoy Your favourite treats"),
  CategoryModel(
      image: "https://placeimg.com/640/480/arch",
      name: "Non Veg",
      subtitle: "Open till 3AM"),
  CategoryModel(
      image: "https://placeimg.com/640/480/arch",
      name: "Vegetables",
      subtitle: "Pick up or send anything"),
  CategoryModel(
      image: "https://placeimg.com/640/480/arch",
      name: "Baby",
      subtitle: "Enjoy Your favourite treats"),
  CategoryModel(
      image: "https://placeimg.com/640/480/arch",
      name: "Fresh",
      subtitle: "Open till 3AM"),
  CategoryModel(
      image: "https://placeimg.com/640/480/arch",
      name: "Beverages",
      subtitle: "Pick up or send anything"),
];
